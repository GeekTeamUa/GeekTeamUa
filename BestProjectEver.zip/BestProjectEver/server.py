from flask import Flask, render_template, request
from keras.models import model_from_json
from PIL import Image
import numpy as np
import os

app = Flask(__name__)

UPLOAD_FOLDER = os.path.basename('../pictures')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def home():
    return render_template("index.html")


@app.route('/result', methods=['GET', 'POST'])
def result():
    # Saving image into the picture directory
    img = request.files["img"]
    file = os.path.join(app.config['UPLOAD_FOLDER'], img.filename)
    img.save(file)

    basewidth = 28
    baseheight = 28
    img = Image.open(img)

    wpercent = (basewidth / float(img.size[0]))
    hsize = int((float(img.size[1]) * float(wpercent)))
    img = img.resize((basewidth, hsize), Image.ANTIALIAS)
    hpercent = (baseheight / float(img.size[1]))
    wsize = int((float(img.size[0]) * float(hpercent)))
    img = img.resize((wsize, baseheight), Image.ANTIALIAS)
    arr = np.array(img)
    os.remove(file)

    json_file = open('model.json', 'r')
    loaded_model_json = json_file.read()
    json_file.close()
    loaded_model = model_from_json(loaded_model_json)
    loaded_model.load_weights("model.h5")
    # score = loaded_model.evaluate(x_test, y_test, verbose=0)
    print("DEBUG DEBUG DEBUG")
    res = loaded_model.predict(arr)
    print("SUPER MEGA NEURAL TEST")
    print(res)

    return render_template("result.html", img=res)


# @app.route('/upload', methods=['POST'])
# def upload_file():
#     file = request.files['image']
#     f = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
#
#     file.save(f)
#     return render_template("index.html", final_text="test")


if __name__ == "__main__":
    app.run(debug=True)
